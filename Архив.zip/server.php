<?php
sleep(3);
echo $_SERVER['REMOTE_ADDR'];
